package school;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Etsh
 */
public class Exam extends javax.swing.JFrame {
     Connection con=null;
PreparedStatement pst = null;
ResultSet rst=null;
String unicode= "?useUnicode=yes&characterEncoding=UTF-8";

    /**
     * Creates new form Home
     */
    public Exam() {
        initComponents();
        con=Connect.connect();
        advsearch();
        jTable1.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 18));
     JTableHeader header = jTable1.getTableHeader();
      header.setBackground(Color.BLACK);
      header.setForeground(Color.white);
          
             fatch();

    }
 public void fatch() {

        try {
            String g = "select student_id as `Student ID `,student_name as `Student Name `,stage as `Stage ` ,class_num as `Class ` from exam ";

            pst = con.prepareStatement(g);
            rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));
             
             TableColumnModel tcm = jTable1.getColumnModel();
              tcm.getColumn(0).setPreferredWidth(100);     
              tcm.getColumn(1).setPreferredWidth(300);    
              tcm.getColumn(2).setPreferredWidth(100); 
           

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
 //---------------------------------------------
 public void advsearch(){
    
   
         if(Search.getSelectedItem().equals("ID"))
      {
          try {
             String g = " SELECT student_id as `Student ID `,student_name as `Student Name `,stage as `Stage `,class_num as `Class `  FROM `exam` WHERE CONCAT(`student_id`)LIKE'%"+ser.getText()+"%'";

               pst = con.prepareStatement(g);
                           rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));
          } catch (Exception e) {
          }
      }else if (Search.getSelectedItem().equals("Name"))
      {
       try {
             String g1 = " SELECT student_id as `Student ID `,student_name as `Student Name `,stage as `Stage `,class_num as `Class `  FROM `exam` WHERE CONCAT(`student_name`)LIKE'%"+ser.getText()+"%'";

               pst = con.prepareStatement(g1);
                           rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));
          } catch (Exception e) {
          }
          
      }else if (Search.getSelectedItem().equals("Stage"))
      {
       try {
             String g12 = " SELECT student_id as `Student ID `,student_name as `Student Name `,stage as `Stage `,class_num as `Class `  FROM `exam` WHERE CONCAT(`stage`)LIKE'%"+ser.getText()+"%'";

               pst = con.prepareStatement(g12);
                           rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));
          } catch (Exception e) {
          }
      
         }else if (Search.getSelectedItem().equals("Class"))
      {
       try {
             String g12 = " SELECT student_id as `Student ID `,student_name as `Student Name `,stage as `Stage `,class_num as `Class `  FROM `exam` WHERE CONCAT(`class_num`)LIKE'%"+ser.getText()+"%'";

               pst = con.prepareStatement(g12);
                           rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));
          } catch (Exception e) {
          }
      }
     }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        test1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        notes = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        test2 = new javax.swing.JTextField();
        test3 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        test4 = new javax.swing.JTextField();
        test5 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        test6 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        test7 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        test8 = new javax.swing.JTextField();
        precint = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        stage = new javax.swing.JTextField();
        student_name = new javax.swing.JTextField();
        student_id = new javax.swing.JTextField();
        class_num = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ser = new javax.swing.JTextField();
        Search = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1330, 710));
        jPanel1.setLayout(null);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/30.png"))); // NOI18N
        jLabel7.setText("jLabel2");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(30, 190, 80, 40);

        test1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test1.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test1ActionPerformed(evt);
            }
        });
        jPanel1.add(test1);
        test1.setBounds(110, 260, 200, 40);

        notes.setColumns(20);
        notes.setRows(5);
        jScrollPane2.setViewportView(notes);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(410, 460, 200, 80);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/21.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(240, 610, 190, 40);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/18.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(30, 610, 190, 40);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/26.png"))); // NOI18N
        jLabel8.setText("jLabel2");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(330, 460, 80, 40);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/44.png"))); // NOI18N
        jLabel9.setText("jLabel2");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(330, 260, 80, 40);

        test2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test2.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test2ActionPerformed(evt);
            }
        });
        jPanel1.add(test2);
        test2.setBounds(410, 260, 200, 40);

        test3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test3.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test3ActionPerformed(evt);
            }
        });
        jPanel1.add(test3);
        test3.setBounds(110, 310, 200, 40);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/45.png"))); // NOI18N
        jLabel10.setText("jLabel2");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(30, 310, 80, 40);

        test4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test4.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test4ActionPerformed(evt);
            }
        });
        jPanel1.add(test4);
        test4.setBounds(410, 310, 200, 40);

        test5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test5.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test5ActionPerformed(evt);
            }
        });
        jPanel1.add(test5);
        test5.setBounds(110, 360, 200, 40);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/47.png"))); // NOI18N
        jLabel11.setText("jLabel2");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(30, 360, 80, 40);

        test6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test6.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test6ActionPerformed(evt);
            }
        });
        jPanel1.add(test6);
        test6.setBounds(410, 360, 200, 40);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/48.png"))); // NOI18N
        jLabel12.setText("jLabel2");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(330, 360, 80, 40);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/46.png"))); // NOI18N
        jLabel13.setText("jLabel2");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(330, 310, 80, 40);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/50.png"))); // NOI18N
        jLabel14.setText("jLabel2");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(330, 410, 80, 40);

        test7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test7.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test7ActionPerformed(evt);
            }
        });
        jPanel1.add(test7);
        test7.setBounds(110, 410, 200, 40);

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/49.png"))); // NOI18N
        jLabel15.setText("jLabel2");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(30, 410, 80, 40);

        test8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        test8.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        test8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test8ActionPerformed(evt);
            }
        });
        jPanel1.add(test8);
        test8.setBounds(410, 410, 200, 40);

        precint.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        precint.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        precint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precintActionPerformed(evt);
            }
        });
        jPanel1.add(precint);
        precint.setBounds(110, 460, 120, 40);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/52.png"))); // NOI18N
        jLabel16.setText("jLabel2");
        jPanel1.add(jLabel16);
        jLabel16.setBounds(230, 460, 80, 40);

        phone.setEditable(false);
        phone.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        phone.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });
        jPanel1.add(phone);
        phone.setBounds(110, 190, 220, 40);

        stage.setEditable(false);
        stage.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        stage.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        stage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stageActionPerformed(evt);
            }
        });
        jPanel1.add(stage);
        stage.setBounds(420, 140, 180, 40);

        student_name.setEditable(false);
        student_name.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        student_name.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        student_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                student_nameActionPerformed(evt);
            }
        });
        jPanel1.add(student_name);
        student_name.setBounds(110, 140, 220, 40);

        student_id.setEditable(false);
        student_id.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        student_id.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        student_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                student_idActionPerformed(evt);
            }
        });
        jPanel1.add(student_id);
        student_id.setBounds(110, 90, 220, 40);

        class_num.setEditable(false);
        class_num.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        class_num.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        class_num.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                class_numActionPerformed(evt);
            }
        });
        jPanel1.add(class_num);
        class_num.setBounds(420, 90, 180, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/34.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(630, 50, 120, 40);

        ser.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ser.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        ser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                serMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                serMouseEntered(evt);
            }
        });
        ser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                serKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serKeyReleased(evt);
            }
        });
        jPanel1.add(ser);
        ser.setBounds(750, 50, 240, 40);

        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Name", "Stage", "Class" }));
        jPanel1.add(Search);
        Search.setBounds(990, 50, 130, 40);

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/43.png"))); // NOI18N
        jLabel17.setText("jLabel2");
        jPanel1.add(jLabel17);
        jLabel17.setBounds(30, 260, 80, 40);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/25.png"))); // NOI18N
        jLabel18.setText("jLabel2");
        jPanel1.add(jLabel18);
        jLabel18.setBounds(340, 140, 80, 40);

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/23.png"))); // NOI18N
        jLabel19.setText("jLabel2");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(30, 140, 80, 40);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/28.png"))); // NOI18N
        jLabel20.setText("jLabel2");
        jPanel1.add(jLabel20);
        jLabel20.setBounds(340, 90, 80, 40);

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/22.png"))); // NOI18N
        jLabel21.setText("jLabel2");
        jPanel1.add(jLabel21);
        jLabel21.setBounds(30, 90, 80, 40);

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/51.png"))); // NOI18N
        jLabel22.setText("jLabel2");
        jPanel1.add(jLabel22);
        jLabel22.setBounds(30, 460, 80, 40);

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Stage", "Class"
            }
        ));
        jTable1.setRowHeight(35);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(630, 100, 660, 570);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/612.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(-30, 0, 1400, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Home c = new Home();
        c.show();
        this.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void test1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test1ActionPerformed

    private void test2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test2ActionPerformed

    private void test3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test3ActionPerformed

    private void test4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test4ActionPerformed

    private void test5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test5ActionPerformed

    private void test6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test6ActionPerformed

    private void test7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test7ActionPerformed

    private void test8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_test8ActionPerformed

    private void precintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precintActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precintActionPerformed

    private void stageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stageActionPerformed

    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneActionPerformed

    private void class_numActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_class_numActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_class_numActionPerformed

    private void student_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_student_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_student_nameActionPerformed

    private void student_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_student_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_student_idActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
         try {

            String sql = "update exam set test1='" + test1.getText().toString() + "',test2='" + test2.getText() + "',test3='" + test3.getText() + "',test4='" + test4.getText() + "',test5='" + test5.getText() + "',test6='" + test6.getText() + "',test7='" + test7.getText() + "',test8='" + test8.getText() + "',notes='" + notes.getText() + "' where student_id='" + student_id.getText() + "' ";

            pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Student data added");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        fatch();
        
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_jTable1KeyReleased

    private void serMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_serMouseClicked
        // TODO add your handling code here:
                      

    }//GEN-LAST:event_serMouseClicked

    private void serMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_serMouseEntered
        // TODO add your handling code here:

    }//GEN-LAST:event_serMouseEntered

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int r = jTable1.getSelectedRow();
        String n = jTable1.getModel().getValueAt(r, 0).toString();
        try {

            String sql1 = "Select * from exam where student_id = '" + n + "'";
            pst = con.prepareStatement(sql1);
            rst = pst.executeQuery();

            if (rst.next()) {
                
                String code = rst.getString("student_id");
                student_id.setText(code);

                String x = rst.getString("student_name");
                student_name.setText(x);

                String x1 = rst.getString("stage");
                stage.setText(x1);

                String x2 = rst.getString("class_num");
                class_num.setText(x2);

                String x4 = rst.getString("test1");
                test1.setText(x4);

                String x5 = rst.getString("test2");
                test2.setText(x5);

                String x3 = rst.getString("test3");
                test3.setText(x3);
                
                String x9 = rst.getString("test4");
                test4.setText(x9);
                
                String x10 = rst.getString("test5");
                test5.setText(x10);
                
                String x6 = rst.getString("test6");
                test6.setText(x6);
                
                String x7 = rst.getString("test7");
                test7.setText(x7);
                
                String x8 = rst.getString("test8");
                test8.setText(x8);
                
                String x11 = rst.getString("phone");
                phone.setText(x11);
                
                String x12 = rst.getString("notes");
                notes.setText(x12);
              

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            JOptionPane.showMessageDialog(this, " خطأ فى أسترجاع البيانات" + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void serKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serKeyPressed
        // TODO add your handling code here:
          advsearch();
    }//GEN-LAST:event_serKeyPressed

    private void serKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serKeyReleased
        // TODO add your handling code here:
          advsearch();
    }//GEN-LAST:event_serKeyReleased

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Search;
    protected javax.swing.JTextField class_num;
    protected javax.swing.JButton jButton3;
    protected javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    protected javax.swing.JTextArea notes;
    protected javax.swing.JTextField phone;
    protected javax.swing.JTextField precint;
    protected javax.swing.JTextField ser;
    protected javax.swing.JTextField stage;
    protected javax.swing.JTextField student_id;
    protected javax.swing.JTextField student_name;
    protected javax.swing.JTextField test1;
    protected javax.swing.JTextField test2;
    protected javax.swing.JTextField test3;
    protected javax.swing.JTextField test4;
    protected javax.swing.JTextField test5;
    protected javax.swing.JTextField test6;
    protected javax.swing.JTextField test7;
    protected javax.swing.JTextField test8;
    // End of variables declaration//GEN-END:variables
}
