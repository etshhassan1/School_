package school;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Etsh
 */
public class Pass extends javax.swing.JFrame {
    Connection conn=null;
    PreparedStatement preparedStatement=null;
    ResultSet resultSet=null;
    

    /**
     * Creates new form Home
     */
    public Pass() {
        initComponents();
                        conn=Connect.connect();
                         Default();

    }

   void Default() {

        try {
            String sql = "select * from login";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            String sql1 = " select user_name  as `إسم المستخدم ` , password as `الرقم السري `  from login";
            PreparedStatement preparedStatement1 = conn.prepareStatement(sql1);
            ResultSet rs = preparedStatement1.executeQuery();
if(resultSet.next()){
            tablePatient.setModel(DbUtils.resultSetToTableModel(rs));
}
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error Here : " + e.getMessage());
            e.printStackTrace();
        }

    }
    void reset()
    {
    txtConfirmNewPassword.setText("");
    txtOldPassword.setText("");
    txtUserName.setText("");
    txtOldPassword.setText("");
    txtNewPassword.setText("");
    
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablePatient = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        txtUserName = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        saveBtn = new javax.swing.JButton();
        saveBtn1 = new javax.swing.JButton();
        saveBtn2 = new javax.swing.JButton();
        txtOldPassword = new javax.swing.JPasswordField();
        txtNewPassword = new javax.swing.JPasswordField();
        txtConfirmNewPassword = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1330, 710));
        jPanel1.setLayout(null);

        tablePatient.setAutoCreateRowSorter(true);
        tablePatient.setBackground(new java.awt.Color(0, 0, 0));
        tablePatient.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tablePatient.setForeground(new java.awt.Color(255, 255, 255));
        tablePatient.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Username", "Password"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablePatient.setRowHeight(35);
        tablePatient.getTableHeader().setReorderingAllowed(false);
        tablePatient.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablePatientMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tablePatientMouseEntered(evt);
            }
        });
        tablePatient.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tablePatientKeyPressed(evt);
            }
        });
        jScrollPane5.setViewportView(tablePatient);

        jPanel1.add(jScrollPane5);
        jScrollPane5.setBounds(540, 30, 760, 560);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/21.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(140, 520, 190, 40);

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/801.png"))); // NOI18N
        jLabel15.setText("jLabel2");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(90, 80, 290, 40);

        txtUserName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtUserName.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txtUserName);
        txtUserName.setBounds(90, 120, 290, 40);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/802.png"))); // NOI18N
        jLabel16.setText("jLabel2");
        jPanel1.add(jLabel16);
        jLabel16.setBounds(90, 190, 290, 40);

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/807.png"))); // NOI18N
        jPanel1.add(jLabel19);
        jLabel19.setBounds(90, 300, 290, 40);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/805.png"))); // NOI18N
        jPanel1.add(jLabel18);
        jLabel18.setBounds(90, 400, 290, 40);

        saveBtn.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        saveBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/810.png"))); // NOI18N
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });
        jPanel1.add(saveBtn);
        saveBtn.setBounds(1080, 610, 200, 50);

        saveBtn1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        saveBtn1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/808.png"))); // NOI18N
        saveBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtn1ActionPerformed(evt);
            }
        });
        jPanel1.add(saveBtn1);
        saveBtn1.setBounds(550, 610, 200, 50);

        saveBtn2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        saveBtn2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/809.png"))); // NOI18N
        saveBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtn2ActionPerformed(evt);
            }
        });
        jPanel1.add(saveBtn2);
        saveBtn2.setBounds(810, 610, 200, 50);

        txtOldPassword.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtOldPassword.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txtOldPassword);
        txtOldPassword.setBounds(90, 230, 290, 40);

        txtNewPassword.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtNewPassword.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txtNewPassword);
        txtNewPassword.setBounds(90, 340, 290, 40);

        txtConfirmNewPassword.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtConfirmNewPassword.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txtConfirmNewPassword);
        txtConfirmNewPassword.setBounds(90, 440, 290, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/17.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1330, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tablePatientMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablePatientMouseClicked
 try {

            int r = tablePatient.getSelectedRow();
            String data = tablePatient.getModel().getValueAt(r, 0).toString();
            String sql = " select * from login where  user_name='" + data + "'";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {

                //1-
                String Name = resultSet.getString("user_name");
                txtUserName.setText(Name);

                // 2-
                String docName = resultSet.getString("password");
                txtOldPassword.setText(docName);

            }

        }catch(Exception ex)
        {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            JOptionPane.showMessageDialog(this, " خطأ فى أسترجاع البيانات"  + ex.getMessage());
            ex.printStackTrace();
        }
        
        // TODO add your handling code here:
    }//GEN-LAST:event_tablePatientMouseClicked

    private void tablePatientMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablePatientMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_tablePatientMouseEntered

    private void tablePatientKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablePatientKeyPressed

        // TODO add your handling code here:
    }//GEN-LAST:event_tablePatientKeyPressed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Reg c = new Reg();
        c.show();
        this.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
Login c1 = new Login();
        c1.show();
        this.hide();        

        // TODO add your handling code here:
    }//GEN-LAST:event_saveBtnActionPerformed

    private void saveBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtn1ActionPerformed
        // TODO add your handling code here:
         String userName=txtUserName.getText();
        String oldPassword=txtOldPassword.getText().trim();
        String newPassword=txtNewPassword.getText().trim();
        String confirmNewPassword=txtConfirmNewPassword.getText().trim();
        if(userName.equals(""))
        {
            JOptionPane.showMessageDialog(null, "أدخل إسم المستخدم ");
            //     reset();
        }
        else if(oldPassword.equals(""))
        {
            JOptionPane.showMessageDialog(null, "أدخل  الرقم السري القديم  ");
            // reset();
        }
        else if(newPassword.equals(""))
        {
            JOptionPane.showMessageDialog(null, "أدخل الرقم السري الجديد  ");
            // reset();
        }
        else if(confirmNewPassword.equals(""))
        {
            JOptionPane.showMessageDialog(null, "أدخل تأكيد الرقم السري الجديد  ");
            // reset();
        }
        else if(!newPassword.equals(confirmNewPassword))
        {
            JOptionPane.showMessageDialog(null, "تأكيد الرقم السري لايطابق الرقم السري الجديد   ");
            // reset();

        }
        else if(newPassword.equals(oldPassword))
        {
            JOptionPane.showMessageDialog(null, "تأكيدالرقم السري القديم يطابق الرقم السري الجديد   ");
            // reset();
            txtConfirmNewPassword.setText(null);
            txtNewPassword.setText(null);
        }

        else{
            conn=Connect.connect();
            String sql="select user_name , password from login where user_name='"+userName+"' and password='"+oldPassword+"'";
            try{
                preparedStatement=conn.prepareStatement(sql);
                resultSet=preparedStatement.executeQuery();
                if(resultSet.next())
                {
                    String name =resultSet.getString("user_name");
                    String pass=resultSet.getString("password");
                    if(userName.equals(name)  && oldPassword.equals(pass))
                    {
                        String sql2="update login set password ='"+newPassword+"'  where user_name ='"+userName+"'";
                        preparedStatement=conn.prepareStatement(sql2);
                        preparedStatement.execute();
                        JOptionPane.showMessageDialog(null, "Password changed successfully ");

                        reset();
                    }

                }else

                {
                    JOptionPane.showMessageDialog(null, "لا يوجد مستخدم بهذا الأسم");
                    reset();
                }

            }catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "لا يوجد مستخدم بهذا الأسم");
                reset();
            }

        }
    }//GEN-LAST:event_saveBtn1ActionPerformed

    private void saveBtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtn2ActionPerformed
        // TODO add your handling code here:
        try {
            if (txtUserName.getText().equals(""))
            {
                JOptionPane.showMessageDialog(null, " برجاء إختيار  المستخدم المراد حذف بياناته ");
            }
            else {
                String sql = "DELETE FROM login WHERE user_name= '" + txtUserName.getText() + "' ";
                preparedStatement = conn.prepareStatement(sql);
                preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(this, "تم حذف البيانات ");
                txtUserName.setText(null);
                txtOldPassword.setText(null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, " خطأفي حذف البيانات ");
        }
    }//GEN-LAST:event_saveBtn2ActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    protected javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton saveBtn1;
    private javax.swing.JButton saveBtn2;
    private javax.swing.JTable tablePatient;
    private javax.swing.JPasswordField txtConfirmNewPassword;
    private javax.swing.JPasswordField txtNewPassword;
    private javax.swing.JPasswordField txtOldPassword;
    private javax.swing.JTextField txtUserName;
    // End of variables declaration//GEN-END:variables
}
