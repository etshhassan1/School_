package school;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Etsh
 */
public class Table extends javax.swing.JFrame {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rst = null;
    String unicode = "?useUnicode=yes&characterEncoding=UTF-8";

    /**
     * Creates new form Home
     */
    public Table() {
        initComponents();
        con = Connect.connect();
        fullcomp();
        fullcomp1();
        fullcomp2();
        jTable1.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 18));
     JTableHeader header = jTable1.getTableHeader();
      header.setBackground(Color.BLACK);
      header.setForeground(Color.white);
      
                      fatch();

    }
    public void fatch() {

        try {
            String g = "select table_id as `ID `,class_num as `Class Number `,day as `Day `,time as `Time ` from time_table ";

            pst = con.prepareStatement(g);
            rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));
             TableColumnModel tcm = jTable1.getColumnModel();
              tcm.getColumn(0).setPreferredWidth(100);     
              tcm.getColumn(1).setPreferredWidth(300);    
              tcm.getColumn(2).setPreferredWidth(100);   
              tcm.getColumn(3).setPreferredWidth(80);
     

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

   public void fullcomp() {
      

        try {
            String sql = "select * from stage";
            pst = con.prepareStatement(sql);
            rst = pst.executeQuery();

            while (rst.next()) {

                String anatomy = rst.getString("stage_name");
                stage.addItem(anatomy);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
   
    } 
   //-------------------------
   
   public void fullcomp1() {
      

        try {
            String sql = "select * from class_st";
            pst = con.prepareStatement(sql);
            rst = pst.executeQuery();

            while (rst.next()) {

                String anatomy = rst.getString("cls_name");
                class_num.addItem(anatomy);
                                                Search.addItem(anatomy);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
   
    } 
   //---------------------------------
   public void fullcomp2() {
      
      //   String X = "Teacher" ;

        try {
            String sql = "select * from teacher ";
            pst = con.prepareStatement(sql);
            rst = pst.executeQuery();

            while (rst.next()) {

                String anatomy = rst.getString("name");
                teacher_name.addItem(anatomy);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
   
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        table_id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        notes = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        subject = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        stage = new javax.swing.JComboBox<>();
        day = new javax.swing.JComboBox<>();
        teacher_name = new javax.swing.JComboBox<>();
        time = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        class_num = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        Search = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1330, 710));
        jPanel1.setLayout(null);

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "price", "Teacher Name", "Notes"
            }
        ));
        jTable1.setRowHeight(35);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(452, 122, 810, 480);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/22.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(30, 80, 80, 40);

        table_id.setEditable(false);
        table_id.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        table_id.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        table_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                table_idActionPerformed(evt);
            }
        });
        jPanel1.add(table_id);
        table_id.setBounds(110, 80, 240, 40);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/28.png"))); // NOI18N
        jLabel3.setText("jLabel2");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(30, 180, 80, 40);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/63.png"))); // NOI18N
        jLabel4.setText("jLabel2");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(30, 330, 80, 40);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/35.png"))); // NOI18N
        jLabel5.setText("jLabel2");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(30, 280, 80, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/25.png"))); // NOI18N
        jLabel6.setText("jLabel2");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(30, 130, 80, 40);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/26.png"))); // NOI18N
        jLabel7.setText("jLabel2");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(30, 430, 80, 40);

        notes.setColumns(20);
        notes.setRows(5);
        jScrollPane2.setViewportView(notes);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(110, 430, 240, 80);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/19.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(110, 580, 190, 40);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/20.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(110, 630, 190, 40);

        subject.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        subject.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(subject);
        subject.setBounds(110, 280, 240, 40);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/64.png"))); // NOI18N
        jLabel8.setText("jLabel2");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(30, 380, 80, 40);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/21.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(1070, 620, 190, 40);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/18.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(110, 530, 190, 40);

        stage.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jPanel1.add(stage);
        stage.setBounds(110, 130, 240, 40);

        day.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        day.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Day", "Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri" }));
        day.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dayActionPerformed(evt);
            }
        });
        jPanel1.add(day);
        day.setBounds(110, 330, 240, 40);

        teacher_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        teacher_name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                teacher_nameItemStateChanged(evt);
            }
        });
        teacher_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacher_nameActionPerformed(evt);
            }
        });
        teacher_name.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                teacher_nameKeyPressed(evt);
            }
        });
        jPanel1.add(teacher_name);
        teacher_name.setBounds(110, 230, 240, 40);

        time.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        time.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Time", "8 AM", "9 Am", "10 Am", "11 Am", "12 PM", "1 PM", "2 PM", "3 PM", "4 PM" }));
        jPanel1.add(time);
        time.setBounds(110, 380, 240, 40);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/27.png"))); // NOI18N
        jLabel9.setText("jLabel2");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(30, 230, 80, 40);

        class_num.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jPanel1.add(class_num);
        class_num.setBounds(110, 180, 240, 40);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/34.png"))); // NOI18N
        jLabel10.setText("jLabel2");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(450, 70, 120, 40);

        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jPanel1.add(Search);
        Search.setBounds(570, 70, 200, 40);

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/34.png"))); // NOI18N
        jPanel1.add(jButton5);
        jButton5.setBounds(790, 70, 120, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/17.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(-70, 0, 1400, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void table_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_table_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_table_idActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Home c = new Home();
        c.show();
        this.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void dayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dayActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        if(subject.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Please Enter Subject");
                return ;

     }
         if(stage.getSelectedItem().equals("Select Stage"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Stage ");
       return ;
       }  
         if(class_num.getSelectedItem().equals("Select Class"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Class ");
       return ;
       }  
         if(teacher_name.getSelectedItem().equals("Select Teacher"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Teacher ");
       return ;
       }  
         
         if(day.getSelectedItem().equals("Select Day"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Day ");
       return ;
       }  
         
         if(time.getSelectedItem().equals("Select Time"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Time ");
       return ;
       }  
        //---------------------------------        
         try {

                String x = "select * from time_table where class_num = '" + class_num.getSelectedItem() + "' and day = '" + day.getSelectedItem() + "'and time = '" + time.getSelectedItem() + "'";
                pst = con.prepareStatement(x);
                rst = pst.executeQuery(x);
                if (rst.next()) {
                    JOptionPane.showMessageDialog(null, "The Class Is Busy In This Time !!!!");
                } else {
             

            String sql = "insert into time_table(stage,class_num,teacher_name,subject,day,time,notes) values "
                    + "   ('" + stage.getSelectedItem()+ "','" + class_num.getSelectedItem() + "','" + teacher_name.getSelectedItem() + "','" + subject.getText() + "','" + day.getSelectedItem() + "','" + time.getSelectedItem() + "','" + notes.getText() + "')";

            pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Saved Successfully");
                }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
        fatch();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {

            String sql = "update time_table set stage='" + stage.getSelectedItem().toString() + "',class_num='" + class_num.getSelectedItem() + "',teacher_name='" + teacher_name.getSelectedItem() + "',subject='" + subject.getText() + "',day='" + day.getSelectedItem() + "',time='" + time.getSelectedItem() + "',notes='" + notes.getText() + "'where table_id='" + table_id.getText() + "' ";

            pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Edited Successfully");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        fatch();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
         int val = JOptionPane.showConfirmDialog(null, "Do You Want To Delete ");
        if (val == 0) {
        }
        try {
            String sql = "delete from time_table where table_id ='" + table_id.getText() + "'";

            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Deleted Successfully");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        fatch();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int r = jTable1.getSelectedRow();
        String n = jTable1.getModel().getValueAt(r, 0).toString();
        try {

            String sql1 = "Select * from time_table where table_id = '" + n + "'";
            pst = con.prepareStatement(sql1);
            rst = pst.executeQuery();

            if (rst.next()) {
                this.hide();
            Table NC = new Table();
            NC.setVisible(true);
                String code = rst.getString("table_id");
                 NC.table_id.setText(code);

                String x = rst.getString("stage");
                 NC.stage.setSelectedItem(x);

                String x6 = rst.getString("class_num");
                 NC.class_num.setSelectedItem(x6);

                String x1 = rst.getString("teacher_name");
                 NC.teacher_name.setSelectedItem(x1);

                String x2 = rst.getString("subject");
                 NC.subject.setText(x2);

                String x4 = rst.getString("day");
                 NC.day.setSelectedItem(x4);

                String x5 = rst.getString("time");
                 NC.time.setSelectedItem(x5);

                String x3 = rst.getString("notes");
                 NC.notes.setText(x3);
                
               

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            JOptionPane.showMessageDialog(this, " خطأ فى أسترجاع البيانات" + e.getMessage());
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void teacher_nameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_teacher_nameKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacher_nameKeyPressed

    private void teacher_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacher_nameActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_teacher_nameActionPerformed

    private void teacher_nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_teacher_nameItemStateChanged
        // TODO add your handling code here:
        if (teacher_name.getSelectedIndex() == 0) {
            
        } else {
            String anatomy = teacher_name.getSelectedItem().toString();
            
            String Sql = "select * from teacher where name = '" + anatomy + "' ";
          //  String number = namber.getText();
            try {
                pst = con.prepareStatement(Sql);
                rst = pst.executeQuery();
                if (rst.next()) {
                    
              
                   
                    String x = rst.getString("subject");
                    subject.setText(x);
                 }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, " error " + e.getMessage());
            }
        }
    }//GEN-LAST:event_teacher_nameItemStateChanged

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Search;
    private javax.swing.JComboBox<String> class_num;
    private javax.swing.JComboBox<String> day;
    protected javax.swing.JButton jButton1;
    protected javax.swing.JButton jButton2;
    protected javax.swing.JButton jButton3;
    protected javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    protected javax.swing.JTextArea notes;
    private javax.swing.JComboBox<String> stage;
    protected javax.swing.JTextField subject;
    protected javax.swing.JTextField table_id;
    private javax.swing.JComboBox<String> teacher_name;
    private javax.swing.JComboBox<String> time;
    // End of variables declaration//GEN-END:variables
}
