package school;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.JTableHeader;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Etsh
 */
public class stu_pro2 extends javax.swing.JFrame {

     Connection con=null;
    PreparedStatement st=null;
    ResultSet rs=null;
    
    public stu_pro2() {
        initComponents();
        
         con=Connect.connect();
         fatch();
         advsearch();
         fullcomp1();
         jTable1.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 18));
     JTableHeader header = jTable1.getTableHeader();
      header.setBackground(Color.BLACK);
      header.setForeground(Color.white);
        
    }

    public void fatch(){
    try {
     
       String g = " select id_pro as `ID `,date_pro as `Date ` ,first_side as `First Side `,second_side as `Second Side ` from pro3 ";



    st =con.prepareStatement(g);
    rs=st.executeQuery();

    
    jTable1.setModel(DbUtils.resultSetToTableModel(rs));
        
    } catch (Exception e) {
    JOptionPane.showMessageDialog(null, e);
    } 
}
        public void advsearch(){
    
   con =Connect.connect();
   if(Search.getSelectedItem().equals("ID" ))
      {
          try {
              
              String g = "select select id_pro as `ID `,date_pro as `Date ` ,first_side as `First Side `,second_side as `Second Side ` from pro3 where id_pro='"+ser.getText()+"' " ;

               st = con.prepareStatement(g);
               rs = st.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          } catch (Exception e) {
          }
      }else if (Search.getSelectedItem().equals("Name"))
      {
       try {
              
              String g1 = "select select id_pro as `ID `,date_pro as `Date ` ,first_side as `First Side `,second_side as `Second Side ` from pro3 where first_side ='"+ser.getText()+"'|| second_side ='"+ser.getText()+"' " ;

               st = con.prepareStatement(g1);
               rs = st.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          } catch (Exception e) {
          }
          
      }else if (Search.getSelectedItem().equals("Supervisor"))
      {
       try {
              
               String g12 = "select select id_pro as `ID `,date_pro as `Date ` ,first_side as `First Side `,second_side as `Second Side ` from pro3 where supervi='"+ser.getText()+"' " ;

               st = con.prepareStatement(g12);
               rs = st.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          } catch (Exception e) {
          }
      }
     }
    //-----------------------------------
     public void fullcomp1() {
      
         String X = "HR" ;

        try {
            String sql5 = "select * from employees where spc ='" + X + "'";
            st = con.prepareStatement(sql5);
            rs = st.executeQuery();

            while (rs.next()) {

                String anatomy = rs.getString("employees_name");
                supervi.addItem(anatomy);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
   
    }   
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        date_pro = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        first_side = new javax.swing.JTextField();
        second_side = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        id_pro = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        supervi = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        super_notes = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        first_notes = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        second_notes = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        Search = new javax.swing.JComboBox<>();
        ser = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1330, 710));
        jPanel1.setLayout(null);

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id", "date", "first side", "second side"
            }
        ));
        jTable1.setRowHeight(35);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(510, 120, 800, 490);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/21.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(1120, 620, 190, 40);

        date_pro.setEditable(false);
        date_pro.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        date_pro.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        date_pro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                date_proActionPerformed(evt);
            }
        });
        jPanel1.add(date_pro);
        date_pro.setBounds(110, 110, 240, 40);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/22.png"))); // NOI18N
        jLabel12.setText("jLabel2");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(30, 60, 80, 40);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/53.png"))); // NOI18N
        jLabel3.setText("jLabel2");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(30, 110, 80, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/606.png"))); // NOI18N
        jLabel6.setText("jLabel2");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(30, 160, 80, 40);

        first_side.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        first_side.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(first_side);
        first_side.setBounds(110, 160, 240, 40);

        second_side.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        second_side.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(second_side);
        second_side.setBounds(110, 210, 240, 40);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/607.png"))); // NOI18N
        jLabel5.setText("jLabel2");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(30, 210, 80, 40);

        id_pro.setEditable(false);
        id_pro.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        id_pro.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        id_pro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_proActionPerformed(evt);
            }
        });
        jPanel1.add(id_pro);
        id_pro.setBounds(110, 60, 240, 40);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/608.png"))); // NOI18N
        jLabel7.setText("jLabel2");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 480, 80, 40);

        supervi.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(supervi);
        supervi.setBounds(110, 260, 240, 40);

        super_notes.setColumns(20);
        super_notes.setFont(new java.awt.Font("Mongolian Baiti", 1, 18)); // NOI18N
        super_notes.setRows(5);
        jScrollPane2.setViewportView(super_notes);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(20, 520, 360, 100);

        first_notes.setColumns(20);
        first_notes.setFont(new java.awt.Font("Mongolian Baiti", 1, 18)); // NOI18N
        first_notes.setRows(5);
        jScrollPane3.setViewportView(first_notes);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(20, 370, 200, 90);

        second_notes.setColumns(20);
        second_notes.setFont(new java.awt.Font("Mongolian Baiti", 1, 18)); // NOI18N
        second_notes.setRows(5);
        jScrollPane4.setViewportView(second_notes);

        jPanel1.add(jScrollPane4);
        jScrollPane4.setBounds(240, 370, 190, 90);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/608.png"))); // NOI18N
        jLabel8.setText("jLabel2");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(30, 260, 80, 40);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/606.png"))); // NOI18N
        jLabel9.setText("jLabel2");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(20, 330, 80, 40);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/607.png"))); // NOI18N
        jLabel10.setText("jLabel2");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(240, 330, 80, 40);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/18.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(510, 620, 190, 40);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/19.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(710, 620, 190, 40);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/20.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(920, 620, 190, 40);

        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Name", "Supervisor" }));
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        jPanel1.add(Search);
        Search.setBounds(870, 60, 130, 40);

        ser.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ser.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        ser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                serMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                serMouseEntered(evt);
            }
        });
        jPanel1.add(ser);
        ser.setBounds(630, 60, 240, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/34.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(510, 60, 120, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/17.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1330, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        problem c = new problem();
        c.show();
        this.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void date_proActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_date_proActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_date_proActionPerformed

    private void id_proActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_proActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_proActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

         con =Connect.connect();
   
  
     if(first_side.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the first student name");
     }
     
     if(second_side.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the second student name");
     }
     
     if(supervi.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the superviser name ");
     } 
     
     if(first_notes.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the first note to the first student");
     }
    
     if(second_notes.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the second note to the second student");
     }
     
     if(super_notes.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the report by supervisor");
     }
        
     try{
         
       
        
        String sql=" insert into pro3 (date_pro,first_side,second_side,supervi,first_notes,second_notes,super_notes)values( '"+date_pro.getText()+"','"+first_side.getText()+"','"+second_side.getText()+"','"+supervi.getSelectedItem()+"','"+first_notes.getText()+"','"+second_notes.getText()+"','"+super_notes.getText()+"' )";
        st=con.prepareStatement(sql);
        st.execute();
        JOptionPane.showMessageDialog(null, " Saved Successfully "); 
        
         
     }
     catch(Exception e){
         
        JOptionPane.showMessageDialog(null, e.getMessage());  
 
     }
        
        fatch();    
      
     
     

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 
     con =Connect.connect();
        
     if(id_pro.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the id ");
     } 
     
     if(date_pro.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the date");
     }
    
     if(first_side.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the first student name");
     }
     
     if(second_side.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the second student name");
     }
     
     if(supervi.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the superviser name ");
     } 
     
     if(first_notes.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the first note to the first student");
     }
    
     if(second_notes.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the second note to the second student");
     }
     
     if(super_notes.equals(""))
     {
         JOptionPane.showMessageDialog(null, "Enter the report by supervisor");
     }
     
        
     String sql=" update pro3 set first_side='"+first_side.getText()+"',second_side='"+second_side.getText()+"',supervi='"+supervi.getSelectedItem()+"',first_notes='"+first_notes.getText()+"',second_notes='"+second_notes.getText()+"',super_notes='"+super_notes.getText()+"' where id_pro='"+id_pro.getText()+"'";
    
    try{
        
        st=con.prepareStatement(sql);
        st.execute();
         JOptionPane.showMessageDialog(null, " updated Successfully ");   
        
    }catch(Exception e){
        
        JOptionPane.showMessageDialog(null, e.getMessage());   
    }
        
     
      fatch(); 

        

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         con=Connect.connect();
    String sql=" delete from pro3 where id_pro='"+id_pro.getText()+"' ";
    
    try{
        
        st=con.prepareStatement(sql);
        st.execute();
         JOptionPane.showMessageDialog(null, " Deleted Successfully ");   
        
    }catch(Exception e){
        
        JOptionPane.showMessageDialog(null, e.getMessage());   
    }

     fatch(); 
        
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked

       int r=jTable1.getSelectedRow();
        String n = jTable1.getModel().getValueAt(r, 0).toString();
        try{

            String sql1 ="Select * from pro3 where id_pro = '"+n +"'";

            st =con.prepareStatement(sql1);
            rs =st.executeQuery();
            
            if(rs.next())
            {
                String code = rs.getString("id_pro");
                id_pro.setText(code);
                
                String x = rs.getString("date_pro");
                date_pro.setText(x);
                
                String x1 = rs.getString("first_side");
                first_side.setText(x1);
                
                String x2 = rs.getString("second_side");
                second_side.setText(x2);
                
                String x3 = rs.getString("supervi");
                supervi.setSelectedItem(x3);
                
                String x4 = rs.getString("first_notes");
                first_notes.setText(x4);
                
                String x5 = rs.getString("second_notes");
                second_notes.setText(x5);
                
                String x6 = rs.getString("super_notes");
                super_notes.setText(x6);
        
                
            }

        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
            JOptionPane.showMessageDialog(this, " Error to retrieve data" + e.getMessage());
            e.printStackTrace();
        }

        
              
        
        
        
   
    }//GEN-LAST:event_jTable1MouseClicked

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchActionPerformed

    private void serMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_serMouseClicked
        // TODO add your handling code here:
        advsearch();
    }//GEN-LAST:event_serMouseClicked

    private void serMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_serMouseEntered
        // TODO add your handling code here:
                advsearch();

    }//GEN-LAST:event_serMouseEntered

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Search;
    protected javax.swing.JTextField date_pro;
    protected javax.swing.JTextArea first_notes;
    protected javax.swing.JTextField first_side;
    protected javax.swing.JTextField id_pro;
    protected javax.swing.JButton jButton1;
    protected javax.swing.JButton jButton2;
    protected javax.swing.JButton jButton3;
    protected javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    protected javax.swing.JTextArea second_notes;
    protected javax.swing.JTextField second_side;
    protected javax.swing.JTextField ser;
    protected javax.swing.JTextArea super_notes;
    private javax.swing.JComboBox<String> supervi;
    // End of variables declaration//GEN-END:variables
}
