package school;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import net.proteanit.sql.DbUtils;
import java.text.SimpleDateFormat;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import static java.lang.Thread.sleep;
import javax.swing.JOptionPane;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.management.remote.JMXConnectorFactory.connect;
import javax.swing.JTextField;
import net.proteanit.sql.DbUtils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.*;
import java.time.Clock;
import java.util.*;
import java.util.GregorianCalendar;
import java.util.Calendar;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Etsh
 */
public class student extends javax.swing.JFrame {

    ResultSet rs = null;
    PreparedStatement st = null;
    Connection con = null;
    

    /**
     * Creates new form Home
     */
    public student() {
        initComponents();
        con = Connect.connect();

        fullcomp();
        advsearch();
        fullcomp1();
        jTable1.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 18));
     JTableHeader header = jTable1.getTableHeader();
      header.setBackground(Color.BLACK);
      header.setForeground(Color.white);
      jTable1.setModel(DbUtils.resultSetToTableModel(rs));
             TableColumnModel tcm = jTable1.getColumnModel();
              tcm.getColumn(0).setPreferredWidth(100);     
              tcm.getColumn(1).setPreferredWidth(300);    
              tcm.getColumn(2).setPreferredWidth(100);   
              tcm.getColumn(3).setPreferredWidth(80);
                      fatch();

    }

    public void fatch() {
        try {
           String g = "select id as `Student ID `,name as `Student Name `,phone as `Phone ` ,stage as `Stage ` from student";
        // String g = " select id  as `Student ID ` , name as `Student Name` , phone as `Phone`, stage as `Stage ` from student ORDER BY id";

            st = con.prepareStatement(g);
            rs = st.executeQuery();
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
            TableColumnModel tcm = jTable1.getColumnModel();
              tcm.getColumn(0).setPreferredWidth(100);     
              tcm.getColumn(1).setPreferredWidth(300);    
              tcm.getColumn(2).setPreferredWidth(100);   
              tcm.getColumn(3).setPreferredWidth(80);
             
     
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }
//-------------------
    public void fullcomp() {
      

        try {
            String sql = "select * from stage";
            st = con.prepareStatement(sql);
            rs = st.executeQuery();

            while (rs.next()) {

                String anatomy = rs.getString("stage_name");
                stage.addItem(anatomy);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
   
    } 
    //---------
       public void advsearch(){
    
   
         if(Search.getSelectedItem().equals("Name"))
      {
          try {
             String g = " SELECT id as `Student ID `,name as `Student Name ` ,phone,stage as `Stage ` FROM `student` WHERE CONCAT(`name`)LIKE'%"+ser.getText()+"%'";

               st = con.prepareStatement(g);
                           rs = st.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          } catch (Exception e) {
          }
      }else if (Search.getSelectedItem().equals("Phone"))
      {
       try {
             String g1 = " SELECT id as `Student ID `,name as `Student Name ` ,phone,stage as `Stage ` FROM `student` WHERE CONCAT(`phone`)LIKE'%"+ser.getText()+"%'";

               st = con.prepareStatement(g1);
                           rs = st.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          } catch (Exception e) {
          }
          
      }else if (Search.getSelectedItem().equals("Stage"))
      {
       try {
             String g12 = " SELECT id as `Student ID `,name as `Student Name ` ,phone,stage as `Stage ` FROM `student` WHERE CONCAT(`Stage`)LIKE'%"+ser.getText()+"%'";

               st = con.prepareStatement(g12);
                           rs = st.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          } catch (Exception e) {
          }
      }
     }
     public void fullcomp1() {
      

        try {
            String sql = "select * from class_st";
            st = con.prepareStatement(sql);
            rs = st.executeQuery();

            while (rs.next()) {

                String anatomy = rs.getString("cls_name");
                class_num.addItem(anatomy);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
   
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        ph_phone = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        notes = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        age = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        start_date = new com.toedter.calendar.JDateChooser();
        stage = new javax.swing.JComboBox<>();
        class_num = new javax.swing.JComboBox<>();
        Search = new javax.swing.JComboBox<>();
        ser = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        price = new javax.swing.JTextField();
        paid = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        not_paid = new javax.swing.JTextField();
        done = new javax.swing.JTextField();
        number = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1330, 710));
        jPanel1.setLayout(null);

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Student Name", "Student ID", "Phone", "Stage"
            }
        ));
        jTable1.setRowHeight(35);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(450, 170, 820, 440);

        id.setEditable(false);
        id.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        id.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        jPanel1.add(id);
        id.setBounds(110, 90, 240, 40);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/34.png"))); // NOI18N
        jLabel3.setText("jLabel2");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(450, 120, 120, 40);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/31.png"))); // NOI18N
        jLabel4.setText("jLabel2");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(30, 290, 80, 40);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/30.png"))); // NOI18N
        jLabel5.setText("jLabel2");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(30, 240, 80, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/29.png"))); // NOI18N
        jLabel6.setText("jLabel2");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(30, 190, 80, 40);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/26.png"))); // NOI18N
        jLabel7.setText("jLabel2");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(30, 640, 80, 40);

        name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        name.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(name);
        name.setBounds(110, 140, 240, 40);

        address.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        address.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressActionPerformed(evt);
            }
        });
        jPanel1.add(address);
        address.setBounds(110, 290, 240, 40);

        ph_phone.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ph_phone.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(ph_phone);
        ph_phone.setBounds(110, 240, 240, 40);

        phone.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        phone.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(phone);
        phone.setBounds(110, 190, 240, 40);

        notes.setColumns(20);
        notes.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        notes.setRows(5);
        jScrollPane2.setViewportView(notes);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(110, 640, 240, 50);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/19.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(650, 620, 190, 40);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/20.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(850, 620, 190, 40);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/21.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(1060, 620, 190, 40);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/18.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(450, 620, 190, 40);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/33.png"))); // NOI18N
        jLabel8.setText("jLabel2");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(30, 390, 80, 40);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/32.png"))); // NOI18N
        jLabel9.setText("jLabel2");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(30, 340, 80, 40);

        age.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        age.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(age);
        age.setBounds(110, 340, 240, 40);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/28.png"))); // NOI18N
        jLabel10.setText("jLabel2");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(30, 590, 80, 40);

        start_date.setBackground(new java.awt.Color(255, 255, 204));
        start_date.setToolTipText("");
        start_date.setDateFormatString("yyyy-MM-dd");
        start_date.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        start_date.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                start_dateAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel1.add(start_date);
        start_date.setBounds(110, 390, 240, 40);

        stage.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        stage.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                stageItemStateChanged(evt);
            }
        });
        jPanel1.add(stage);
        stage.setBounds(110, 440, 240, 40);

        class_num.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        class_num.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                class_numItemStateChanged(evt);
            }
        });
        class_num.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                class_numKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                class_numKeyReleased(evt);
            }
        });
        jPanel1.add(class_num);
        class_num.setBounds(110, 590, 240, 40);

        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Name", "Phone", "Stage" }));
        jPanel1.add(Search);
        Search.setBounds(810, 120, 130, 40);

        ser.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ser.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        ser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serActionPerformed(evt);
            }
        });
        ser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                serKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serKeyReleased(evt);
            }
        });
        jPanel1.add(ser);
        ser.setBounds(570, 120, 240, 40);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/23.png"))); // NOI18N
        jLabel13.setText("jLabel2");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(30, 140, 80, 40);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/25.png"))); // NOI18N
        jLabel11.setText("jLabel2");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(30, 440, 80, 40);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/22.png"))); // NOI18N
        jLabel12.setText("jLabel2");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(30, 90, 80, 40);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/24.png"))); // NOI18N
        jLabel14.setText("jLabel2");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(30, 490, 80, 40);

        price.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        price.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceActionPerformed(evt);
            }
        });
        jPanel1.add(price);
        price.setBounds(110, 490, 240, 40);

        paid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        paid.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        paid.setText("0.0");
        paid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paidActionPerformed(evt);
            }
        });
        jPanel1.add(paid);
        paid.setBounds(110, 540, 240, 40);

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/610.png"))); // NOI18N
        jLabel15.setText("jLabel2");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(30, 540, 80, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/650.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1400, 760);
        jPanel1.add(not_paid);
        not_paid.setBounds(1310, 90, 0, 10);

        done.setText("Not Done ");
        jPanel1.add(done);
        done.setBounds(30, 700, 10, 0);
        jPanel1.add(number);
        number.setBounds(1310, 80, 10, 10);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Home c = new Home();
        c.show();
        this.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressActionPerformed

    private void start_dateAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_start_dateAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_start_dateAncestorAdded

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        
        
       
        
        
        
         if(stage.getSelectedItem().equals("Select Stage"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Stage ");
       return ;
       }  
         if(class_num.getSelectedItem().equals("Select Class"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Class ");
       return ;
       }  
         if (number.getText().equals("0.0")) {
            JOptionPane.showMessageDialog(null, "The Number Of Student in This Class Complete");
                   return ;

        }
         
         
         
          double x1 = Double.parseDouble(price.getText()); 
          double x2 = Double.parseDouble(paid.getText());      
                   double Restt=0 ;
             Restt = x1 - x2 ;
             not_paid.setText(""+Restt);
             
             
             
             
        try {
            
            
            
            
            
            String sdate = ((JTextField) start_date.getDateEditor().getUiComponent()).getText();

            String sql = "insert into student(name,phone,ph_phone,address,stage,class_num,age,start_date,notes,price,paid,not_paid) values "
                    + "('" + name.getText() + "','" + phone.getText() + "','" + ph_phone.getText() + "','" + address.getText() + "','" + stage.getSelectedItem() + "','" + class_num.getSelectedItem() + "','" + age.getText() + "','" + sdate + "','" + notes.getText() + "','" + price.getText() + "','" + paid.getText() + "','" + not_paid.getText() + "')";

            st = con.prepareStatement(sql);
            st.execute();

            JOptionPane.showMessageDialog(null, "Saved Successfully");
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        //---------------------------------------

        try {

                              double x45 = Double.parseDouble(number.getText()); 
                                                 double Resttt=0 ;
                                           Resttt = x45 - 1 ;


            String sql12 = "update class_st set number='" + Resttt + "' where cls_name='" + class_num.getSelectedItem() + "' ";

            st = con.prepareStatement(sql12);
            st.execute();

            JOptionPane.showMessageDialog(null, "Edited Successfully");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
       
//-----------------------------------------
try {

            String sql2 = "insert into exam(student_name,stage,class_num,test1,test2,test3,test4,test5,test6,test7,test8,phone,notes) values "
                    + "('" + name.getText() + "','" + stage.getSelectedItem()+ "','" + class_num.getSelectedItem()+ "','" + done.getText() + "','" + done.getText() + "','" + done.getText() + "','" + done.getText() + "','" + done.getText() + "','" + done.getText() + "','" + done.getText() + "','" + done.getText() + "','" + ph_phone.getText() + "','" + notes.getText() + "')";

            st = con.prepareStatement(sql2);
            st.execute();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
//-----------------------------------------------
try {

            String sql3 = "insert into payment1(student_name,stage,class_num,price,phone,notes,paid,ph_phone,not_paid) values "
                    + "('" + name.getText() + "','" + stage.getSelectedItem()+ "','" + class_num.getSelectedItem()+ "','" + price.getText() + "','" + phone.getText() + "','" + notes.getText() + "','" + paid.getText() + "','" + ph_phone.getText() + "','" + not_paid.getText() + "')";

            st = con.prepareStatement(sql3);
            st.execute();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }





        fatch();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        if(stage.getSelectedItem().equals("Select Stage"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Stage ");
       return ;
       }  
         if(class_num.getSelectedItem().equals("Select Class"))
       {
       JOptionPane.showMessageDialog(null, "Plese Select Class ");
       return ;
       }  

        try {
                    String sdate = ((JTextField) start_date.getDateEditor().getUiComponent()).getText();

            String sql = "update  student set name='" + name.getText() + "',phone='" + phone.getText() + "',ph_phone='" + ph_phone.getText() + "',address='" + address.getText() + "',stage='" + stage.getSelectedItem() + "',class_num='" + class_num.getSelectedItem() + "',age='" + age.getText() + "',start_date='" + sdate + "',notes='" + notes.getText() + "',price='" + price.getText() + "',not_paid='" + paid.getText() + "',not_paid='" + paid.getText() + "'where id='"+id.getText()+"' " ;

            st = con.prepareStatement(sql);
            st.execute();
            JOptionPane.showMessageDialog(null, "Edited Successfully");
        } catch (Exception e) {

        }
        fatch();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (name.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Enter Name");
        }
        con = Connect.connect();
        String sql = "delete from student where id='" + id.getText() + "'";
        try {
            st = con.prepareStatement(sql);
            st.execute();
            JOptionPane.showMessageDialog(null, "Deleted Successfully");
        } catch (Exception e) {

        }
        fatch();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int r = jTable1.getSelectedRow();
        String n = jTable1.getModel().getValueAt(r, 0).toString();
        try {

            String sql1 = "Select * from student where id = '" + n + "'";

            st = con.prepareStatement(sql1);
            rs = st.executeQuery();

            if (rs.next()) {
                
                
                 this.hide();
            student NC = new student();
            NC.setVisible(true);
            
                String code = rs.getString("id");
                NC.id.setText(code);

                String x = rs.getString("name");
                NC.name.setText(x);
                String x4 = rs.getString("phone");
                NC.phone.setText(x4);

                String x5 = rs.getString("ph_phone");
                NC.ph_phone.setText(x5);

                String x1 = rs.getString("address");
                NC.address.setText(x1);

                String x6 = rs.getString("stage");
                NC.stage.setSelectedItem(x6);

                String x3 = rs.getString("class_num");
                NC.class_num.setSelectedItem(x3);

                String x2 = rs.getString("age");
                NC.age.setText(x2);

                java.sql.Date date2 = rs.getDate("start_date");
                NC.start_date.setDate(date2);

                String x8 = rs.getString("notes");
                NC.notes.setText(x8);
                
                String x9 = rs.getString("price");
                NC.price.setText(x9);
                
                String x10 = rs.getString("paid");
                NC.paid.setText(x10);
                
                String x11 = rs.getString("not_paid");
                NC.not_paid.setText(x11);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            JOptionPane.showMessageDialog(this, " Error to retrieve data" + e.getMessage());
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1MouseClicked

    private void serActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serActionPerformed
      // TODO add your handling code here:
      
      
    }//GEN-LAST:event_serActionPerformed

    private void priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceActionPerformed

    private void paidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paidActionPerformed

    private void stageItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_stageItemStateChanged
        // TODO add your handling code here:
         if (stage.getSelectedIndex() == 0) {
            
        } else {
            String anatomy = stage.getSelectedItem().toString();
            
            String Sql = "select * from stage where stage_name = '" + anatomy + "' ";
            try {
                st = con.prepareStatement(Sql);
                rs = st.executeQuery();
                if (rs.next()) {
                    String x = rs.getString("price");
                    price.setText(x);
                         }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, " error " + e.getMessage());
            }
        }
    }//GEN-LAST:event_stageItemStateChanged

    private void serKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serKeyPressed
        // TODO add your handling code here:
                advsearch();

    }//GEN-LAST:event_serKeyPressed

    private void serKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serKeyReleased
        // TODO add your handling code here:
                advsearch();

    }//GEN-LAST:event_serKeyReleased

    private void class_numKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_class_numKeyPressed
        // TODO add your handling code here:
        fullcomp1();
    }//GEN-LAST:event_class_numKeyPressed

    private void class_numKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_class_numKeyReleased
        // TODO add your handling code here:
        fullcomp1();
    }//GEN-LAST:event_class_numKeyReleased

    private void class_numItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_class_numItemStateChanged
        // TODO add your handling code here:
        if (class_num.getSelectedIndex() == 0) {
            
        } else {
            String anatomy = class_num.getSelectedItem().toString();
            
            String Sql = "select * from class_st where cls_name = '" + anatomy + "' ";
          //  String number = namber.getText();
            try {
                st = con.prepareStatement(Sql);
                rs = st.executeQuery();
                if (rs.next()) {
                    
              
                   
                    String x = rs.getString("number");
                    number.setText(x);
                    
                     
                 }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, " error " + e.getMessage());
            }
        }
    }//GEN-LAST:event_class_numItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Search;
    protected javax.swing.JTextField address;
    protected javax.swing.JTextField age;
    private javax.swing.JComboBox<String> class_num;
    private javax.swing.JTextField done;
    protected javax.swing.JTextField id;
    protected javax.swing.JButton jButton1;
    protected javax.swing.JButton jButton2;
    protected javax.swing.JButton jButton3;
    protected javax.swing.JButton jButton4;
    protected javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    protected javax.swing.JTextField name;
    private javax.swing.JTextField not_paid;
    protected javax.swing.JTextArea notes;
    private javax.swing.JTextField number;
    protected javax.swing.JTextField paid;
    protected javax.swing.JTextField ph_phone;
    protected javax.swing.JTextField phone;
    protected javax.swing.JTextField price;
    protected javax.swing.JTextField ser;
    private javax.swing.JComboBox<String> stage;
    private com.toedter.calendar.JDateChooser start_date;
    // End of variables declaration//GEN-END:variables
}
