package school;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Etsh
 */
public class teacher extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rst = null;
    String unicode = "?useUnicode=yes&characterEncoding=UTF-8";

    public teacher() {
        initComponents();
        con = Connect.connect();

        fatch();
        fullcomp();
        advsearch();
        fullcomp1();
        jTable1.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 18));
        JTableHeader header = jTable1.getTableHeader();
        header.setBackground(Color.BLACK);
        header.setForeground(Color.white);
    }

    public void fatch() {

        try {
            String g = "select teacher_id as `Teacher ID `,name as `Teacher Name `,subject as `Subject ` from teacher ";

            pst = con.prepareStatement(g);
            rst = pst.executeQuery();

            jTable1.setModel(DbUtils.resultSetToTableModel(rst));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
//-------------------

    public void fullcomp() {

        try {
            String sql = "select * from stage";
            pst = con.prepareStatement(sql);
            rst = pst.executeQuery();

            while (rst.next()) {

                String anatomy = rst.getString("stage_name");
                stage.addItem(anatomy);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }

    }
    //--------------------

    public void fullcomp1() {

        String X = "Teacher";

        try {
            String sql = "select * from employees where spc ='" + X + "'";
            pst = con.prepareStatement(sql);
            rst = pst.executeQuery();

            while (rst.next()) {

                String anatomy = rst.getString("employees_name");
                name.addItem(anatomy);
                
                
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }

    }

    public void advsearch() {

        if (Search.getSelectedItem().equals("ID")) {
            try {
                String g = " SELECT teacher_id as `Teacher ID `,name as `Teacher Name `,subject as `Subject ` FROM `teacher` WHERE CONCAT(`teacher_id`)LIKE'%" + ser.getText() + "%'";

                pst = con.prepareStatement(g);
                rst = pst.executeQuery();

                jTable1.setModel(DbUtils.resultSetToTableModel(rst));
            } catch (Exception e) {
            }
        } else if (Search.getSelectedItem().equals("Name")) {
            try {
                String g1 = " SELECT teacher_id as `Teacher ID `,name as `Teacher Name `,subject as `Subject ` FROM `teacher` WHERE CONCAT(`name`)LIKE'%" + ser.getText() + "%'";

                pst = con.prepareStatement(g1);
                rst = pst.executeQuery();

                jTable1.setModel(DbUtils.resultSetToTableModel(rst));
            } catch (Exception e) {
            }

        } else if (Search.getSelectedItem().equals("Subject")) {
            try {
                String g12 = " SELECT teacher_id as `Teacher ID `,name as `Teacher Name `,subject as `Subject ` FROM `teacher` WHERE CONCAT(`subject`)LIKE'%" + ser.getText() + "%'";

                pst = con.prepareStatement(g12);
                rst = pst.executeQuery();

                jTable1.setModel(DbUtils.resultSetToTableModel(rst));
            } catch (Exception e) {
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        teacher_id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        address = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        subject = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        notes = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        Search = new javax.swing.JComboBox<>();
        ser = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        stage = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        name = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1330, 710));
        jPanel1.setLayout(null);

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Name", "price"
            }
        ));
        jTable1.setRowHeight(35);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(450, 110, 800, 500);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/22.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 100, 80, 40);

        teacher_id.setEditable(false);
        teacher_id.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        teacher_id.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        teacher_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacher_idActionPerformed(evt);
            }
        });
        jPanel1.add(teacher_id);
        teacher_id.setBounds(120, 100, 240, 40);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/23.png"))); // NOI18N
        jLabel3.setText("jLabel2");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(40, 150, 80, 40);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/31.png"))); // NOI18N
        jLabel4.setText("jLabel2");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(40, 250, 80, 40);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/29.png"))); // NOI18N
        jLabel5.setText("jLabel2");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(40, 200, 80, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/35.png"))); // NOI18N
        jLabel6.setText("jLabel2");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(40, 350, 80, 40);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/26.png"))); // NOI18N
        jLabel7.setText("jLabel2");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(40, 400, 80, 40);

        address.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        address.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressActionPerformed(evt);
            }
        });
        jPanel1.add(address);
        address.setBounds(120, 250, 240, 40);

        phone.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        phone.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(phone);
        phone.setBounds(120, 200, 240, 40);

        subject.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        subject.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(subject);
        subject.setBounds(120, 350, 240, 40);

        notes.setColumns(20);
        notes.setRows(5);
        jScrollPane2.setViewportView(notes);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(120, 400, 240, 80);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/19.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(650, 620, 190, 40);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/20.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(860, 620, 190, 40);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/21.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(1060, 620, 190, 40);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/18.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(450, 620, 190, 40);

        Search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Name", "Subject" }));
        jPanel1.add(Search);
        Search.setBounds(820, 50, 130, 40);

        ser.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ser.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        ser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serActionPerformed(evt);
            }
        });
        ser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                serKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serKeyReleased(evt);
            }
        });
        jPanel1.add(ser);
        ser.setBounds(580, 50, 240, 40);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/34.png"))); // NOI18N
        jLabel11.setText("jLabel2");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(460, 50, 120, 40);

        stage.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jPanel1.add(stage);
        stage.setBounds(120, 300, 240, 40);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/25.png"))); // NOI18N
        jLabel12.setText("jLabel2");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(40, 300, 80, 40);

        name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        name.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                nameItemStateChanged(evt);
            }
        });
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        jPanel1.add(name);
        name.setBounds(120, 150, 240, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/school/17.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(-60, 0, 1400, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void teacher_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacher_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacher_idActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Home c = new Home();
        c.show();
        this.hide();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {

            String sql = "insert into teacher(name,subject,phone,address,notes,stage) values "
                    + "   ('" + name.getSelectedItem() + "','" + subject.getText() + "','" + phone.getText() + "','" + address.getText() + "','" + notes.getText() + "','" + stage.getSelectedItem() + "')";

            pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "نم اضافة المدرس");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());

        }
        fatch();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {

            String sql = "update teacher set name='" + name.getSelectedItem().toString() + "',subject='" + subject.getText() + "',phone='" + phone.getText() + "',address='" + address.getText() + "',notes='" + notes.getText() + "',stage='" + stage.getSelectedItem() + "' where teacher_id='" + teacher_id.getText() + "' ";

            pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "تم تعديل البيانات");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
                 fatch();    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int val = JOptionPane.showConfirmDialog(null, "هل تريد حذف البيانات ");
        if (val == 0) {
        }
        try {
            String sql = "delete from teacher where teacher_id ='" + teacher_id.getText() + "'";

            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "تم الحذف بنجاح");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        fatch();
           }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int r = jTable1.getSelectedRow();
        String n = jTable1.getModel().getValueAt(r, 0).toString();
        try {

            String sql1 = "Select * from teacher where teacher_id = '" + n + "'";
            pst = con.prepareStatement(sql1);
            rst = pst.executeQuery();

            if (rst.next()) {
                 this.hide();
            teacher NC = new teacher();
            NC.setVisible(true);
                String code = rst.getString("teacher_id");
                NC.teacher_id.setText(code);

                String x = rst.getString("name");
               NC.name.setSelectedItem(x);

                String x6 = rst.getString("subject");
                NC.subject.setText(x6);

                String x1 = rst.getString("phone");
                NC.phone.setText(x1);

                String x2 = rst.getString("address");
                NC.address.setText(x2);

                String x3 = rst.getString("notes");
                NC.notes.setText(x3);

                String x9 = rst.getString("stage");
                NC.stage.setSelectedItem(x9);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            JOptionPane.showMessageDialog(this, " خطأ فى أسترجاع البيانات" + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void serActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serActionPerformed


    }//GEN-LAST:event_serActionPerformed

    private void serKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serKeyPressed

        // TODO add your handling code here:
        advsearch();

    }//GEN-LAST:event_serKeyPressed

    private void serKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serKeyReleased
        // TODO add your handling code here:
        advsearch();

    }//GEN-LAST:event_serKeyReleased

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_nameActionPerformed

    private void nameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_nameItemStateChanged
        // TODO add your handling code here:
      if (name.getSelectedIndex() == 0) {

        } else {
            String anatomy = name.getSelectedItem().toString();

            //  String number = namber.getText();
            try {
                String Sql54 = "select * from employees where employees_name = '" + anatomy + "' ";

                pst = con.prepareStatement(Sql54);
                rst = pst.executeQuery();
                if (rst.next()) {

                    String x = rst.getString("phone");
                    phone.setText(x);

                    String x1 = rst.getString("address");
                    address.setText(x1);

                    String x3 = rst.getString("notes");
                    notes.setText(x3);
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, " error " + e.getMessage());
            }
        }
    }//GEN-LAST:event_nameItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Search;
    protected javax.swing.JTextField address;
    protected javax.swing.JButton jButton1;
    protected javax.swing.JButton jButton2;
    protected javax.swing.JButton jButton3;
    protected javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> name;
    protected javax.swing.JTextArea notes;
    protected javax.swing.JTextField phone;
    protected javax.swing.JTextField ser;
    private javax.swing.JComboBox<String> stage;
    protected javax.swing.JTextField subject;
    protected javax.swing.JTextField teacher_id;
    // End of variables declaration//GEN-END:variables
}
